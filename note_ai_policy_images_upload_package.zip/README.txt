note AI政治介入レポート｜図版6枚と修正XML（2026年11月24日）

このZIPには見出し画像1枚＋本文グラフ5枚が入っています。

【重要】noteはインポート時にインターネットから画像を取り込みます。
まだGitHubへPNGをアップロードしていない状態でXMLを読み込んでも図は入りません。

手順：
1) このZIPを展開します。
2) GitHub https://github.com/gs9w8vw2z6-debug/note-report-images を開きます。
3) mainブランチ直下の Add file → Upload files を開きます。
4) ai_policy_20261124_ で始まるPNG全6枚を選んでアップロードし、Commit changesします。
   既存ファイルの上書きはしないでください。
5) PNGのraw URLが開けることを確認します。
6) 「note_ai_policy_images_ready.xml」をnoteのWordPressインポートで読み込みます。
7) 新しい下書きが作成されます。前の図なし下書きが自動更新されるわけではありません。

図版の公開後に読み込むXMLはこちら（ZIPの中にも同梱）： note_ai_policy_images_ready.xml

画像URL：
https://raw.githubusercontent.com/gs9w8vw2z6-debug/note-report-images/main/ai_policy_20261124_00_heading.png
https://raw.githubusercontent.com/gs9w8vw2z6-debug/note-report-images/main/ai_policy_20261124_01_fcf_overview.png
https://raw.githubusercontent.com/gs9w8vw2z6-debug/note-report-images/main/ai_policy_20261124_02_company_fcf.png
https://raw.githubusercontent.com/gs9w8vw2z6-debug/note-report-images/main/ai_policy_20261124_03_policy_mechanisms.png
https://raw.githubusercontent.com/gs9w8vw2z6-debug/note-report-images/main/ai_policy_20261124_04_funding_simulation.png
https://raw.githubusercontent.com/gs9w8vw2z6-debug/note-report-images/main/ai_policy_20261124_05_scenarios.png

noteの見出し画像設定はインポートだけでは確実に行われません。
記事本文の先頭に見出し画像を挿入しています。必要ならnote編集画面で手動で見出し画像を設定してください。
