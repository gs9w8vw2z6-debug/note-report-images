米国AI政策 Deep Dive / note投稿パッケージ（2026年11月24日）

report_with_figures.html : ブラウザで開く。assets内の図版を相対参照するため、必ずフォルダごと展開してください。
report.docx              : 編集用、図版入り。
report.md / report.txt  : 本文、出典一覧。
note_import_text_only.xml : WordPress WXR 1.2のnoteインポート用。本文と出典は揃っていますが、図版は含めていません。
assets/*.png             : note表示を想定したスマホ用独立図版5枚＋見出し画像。

重要：未アップロードのPNG画像を架空のGitHub raw URLで参照するとnote表示に失敗します。そのため今回のXMLには画像タグを入れていません。
図版はGitHubの公開リポジトリに、既存画像と重複しないファイル名でアップロードしてから、検証済みのraw URLに差し替えたXMLを作成できます。
このZIPに含まれるHTMLはオフラインで画像を表示できます。noteへのXMLインポートは手元で動作検証していません。

数値：5社の設備投資2,304.22億ドル、営業CF1,986.00億ドル、差額 -318.22億ドル（The Capex Reportの表示値から集計）。
